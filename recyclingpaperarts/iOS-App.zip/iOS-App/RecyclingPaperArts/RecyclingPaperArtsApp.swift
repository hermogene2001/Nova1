import SwiftUI

@main
struct RecyclingPaperArtsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
